/*
 * File:   Main.c
 * Author: Iztatik
 *
 * Created on 10 de febrero de 2016, 11:01 AM
 */

#include "Configuration.h"


     char string[7];
     double result;
     unsigned int buff; 

     
int main(void) {
    
    SYSTEM_initialize();
    TRISBbits.TRISB10=0;
    LATBbits.LATB10=1;
    TRISD=0x00;
    LATD=0x00;


    while (1){   
        result = (ADC1_getdata()*11)/13.65;
        buff= (IIR_filter(result));
         
        sprintf(string, "%d", buff);
        UART1_send_string(string);
        putcUART1(0xA);
        while(BusyUART1()); 
        LATBbits.LATB10=0;
        
    }

   
    
    return 0;
}

