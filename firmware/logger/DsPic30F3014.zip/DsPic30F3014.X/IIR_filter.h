
/* 
 * File: IIR_filter
 * Author: Iztatik
 * Comments: Filtro Butterworth de tercer orden  con respuesta IIR y Fc=6hz. 
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef IIR_FILTER_H
#define	IIR_FILTER_H

#include <xc.h>  
#include "Configuration.h"
#include <math.h>

//Coeficientes del filtro
#define a1 2.8492390952
#define a2 2.7096291328
#define a3 0.8599919781

#define b0 0.0000497574
#define b1 0.0001492723
#define b2 0.0001492723
#define b3 0.0000497574



double IIR_filter (double n);


#endif	/* XC_HEADER_TEMPLATE_H */

