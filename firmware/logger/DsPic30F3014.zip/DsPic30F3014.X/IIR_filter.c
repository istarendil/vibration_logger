#include "IIR_filter.h"

double x3,x2,x1,x0,y3,y2,y11,out = 0;

double IIR_filter (double n){
    
    x3=x2;
    x2=x1;
    x1=x0;
    x0=n;
    y3=y2;
    y2=y11;
    y11=out;
    
    out = (b0*x0)+(b1*x1)+(b2*x2)+(b3*x3)+(a1*y11)-(a2*y2)+(a3*y3);
    
    if (out>3300)out=3300;
    //if (out<0)out=0;
    return out;
}





