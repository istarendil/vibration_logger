/* 
 * File: uart1
 * Author: Iztatik 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef UART1_H
#define	UART1_H

#include "Configuration.h"
#include <uart.h>

#define _BAUD 57600
#define _BAUD_RATE ((FCY/_BAUD)/16)-1


void UART1_initialize (void);

void UART1_send_string(char x[20]);

void _ISR _U1RXInterrupt(void);

#endif	/* XC_HEADER_TEMPLATE_H */

